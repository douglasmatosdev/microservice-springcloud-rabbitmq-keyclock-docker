package io.github.cursodsousa.mscartoes.domain;

public enum BandeiraCartao {
    MASTERCARD, VISA
}
